# Welcome to my GitHub.

For my lab I tried the persona feature I made myseld and assignmed myself to all of the epics and a few of the tasks just to get a feeling of what to do.

